<?php 
session_start();
if (isset($_SESSION['errors']) && count($_SESSION['errors']) > 0) {
    foreach ($_SESSION['errors'] as $error) {
        echo "<p>" . htmlspecialchars($error) . "</p>";
    }
    unset($_SESSION['errors']); // Clear errors from the session after displaying them.
}
?>
