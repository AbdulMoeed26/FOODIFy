<?php

include('./template/header.php');

include('./session.php');


?>

<div class="py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Kolachi</h1>
                    <!-- <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Service</li>
                        </ol>
                    </nav> -->
                </div>
            </div>
        </div>
<div class="container  mt-10">
    <div class="row">
    <div class="col-md-8"   >
        <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <button class="nav-link active" id="nav-FastFood-tab" data-bs-toggle="tab" data-bs-target="#FastFood" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Fast Food</button>
            <button class="nav-link" id="nav-Desi-tab" data-bs-toggle="tab" data-bs-target="#nav-Desi" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Desi</button>
        </div>
        </nav>
        <div class="tab-content pt-3" id="nav-tabContent">
        <div class="tab-pane fade show active" id="FastFood" role="tabpanel" aria-labelledby="nav-FastFood-tab">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                    <img src="./img/pizza.webp" style="width: 100%;"/>
                        <h6>zinger burger</h6>
                        <p class="text-muted">RS 200</p>
                        <p class="text-muted">quantity</p>
                        
                    </div>
                    <div class="col-md-4">
                        <img src="./img/sm0p-listing.webp" style="width: 100%;"/>
                        <h6>zinger burger</h6>
                        <!-- <p class="text-muted">500</p> -->
                    </div>

                </div>                
                
            </div>   
        </div>
        <div class="tab-pane fade" id="nav-Desi" role="tabpanel" aria-labelledby="nav-Desi-tab">
        <div class="container">
                <div class="row">
                    <div class="col-md-4">
                    <img src="./img/sm0p-listing.webp" style="width: 100%;"/>
                        <h6>Karahi</h6>
                        <!-- <p class="text-muted">200</p> -->
                    </div>
                    <div class="col-md-4">
                        <img src="./img/pizza.webp" style="width: 100%;"/>
                        <h6>Karahi</h6>
                        <!-- <p class="text-muted">500</p> -->
                    </div>

                </div>                     
            </div> 
        </div>
        </div>
        <div class="col-md-4">
            <h2>Make a reservation</h2>
    
                                <div class="col-12">
                                    <a href="Checkout.php" class="btn btn-primary w-100 py-3" type="submit">Book Your Table</a>
                                </div>
                            </div>
                        
        </div>
        <div class="col-md-4">
        <h3 class="cart-summary-header-empty-cart-title" data-testid="cartlib-cart-title">Your cart</h3>
        <div class="cart-summary-header"><h2 class="cart-summary-header-title">Your order from <span>Kolachi</span></h2></div>

        </div>
    
    </div>   
</div>   


<?php
      include('./template/footer.php');
?>