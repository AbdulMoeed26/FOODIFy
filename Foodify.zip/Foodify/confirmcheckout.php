<?php
include('./session.php');
include('./template/header.php');


$record = [];
$email = $_SESSION['loggeduser'];
$_SESSION['currentpage'] = $_SERVER['REQUEST_URI'];

if (isset($_GET['id'])) {
    $_restaurant_id = $_GET['id'];
    $query1 = "SELECT * FROM resataurant_reg WHERE r_id =" . $_restaurant_id;
    $stmt1 = $con->prepare($query1);
    $stmt1->execute();
    $record = $stmt1->fetchAll(PDO::FETCH_OBJ);
}

// Retrieve the record for the logged-in user
$query3 = "SELECT * FROM customer WHERE c_email = :email";
$stmt3 = $con->prepare($query3);
$stmt3->bindParam(':email', $email, PDO::PARAM_STR);
$stmt3->execute();
$record3 = $stmt3->fetch(PDO::FETCH_OBJ);
$cid = $record3->C_id;


if (isset($_POST['confirm'])) {
    $query5 = "SELECT t_id,tcust_id,trest_id,date
    FROM booktable
    where tcust_id ={$cid}
    ORDER BY date DESC
    LIMIT 1 ";
    $stmt5 = $con->prepare($query5);
    $stmt5->execute();
    $record5 = $stmt5->fetch(PDO::FETCH_OBJ);
    $tableid = $record5->t_id;
    $customerid = $record5->tcust_id;
    $restaurant = $record5->trest_id;
    $date = $record5->date;

    $query6 = "INSERT INTO orderdetails (`otbl_id`,`ocust_id`, `orest_id`, `date`) VALUES (?,?,?,?)";
    $stmt6 = $con->prepare($query6);
    $stmt6->bindParam(1, $tableid);
    $stmt6->bindParam(2, $customerid);
    $stmt6->bindParam(3, $restaurant);
    $stmt6->bindParam(4, $date);
    $stmt6->execute();
}

if (isset($_POST['confirm'])) {
    $porder_id = $_POST['porder_id'];
    $prest_id = $_POST['prest_id'];
    $p_amount = $_POST['p_amount'];
    $pcust_id = $_POST['pcust_id'];
    $p_method = $_POST['p_method'];

    $query6 = "INSERT INTO `payment`(`p_id`, `porder_id`, `prest_id`, `p_amount`, `pcust_id`, `p_method`) VALUES (NULL, ?, ?, ?, ?, ?)";
    $stmt6 = $con->prepare($query6);
    $stmt6->bindParam(1, $porder_id, PDO::PARAM_INT);
    $stmt6->bindParam(2, $prest_id, PDO::PARAM_INT);
    $stmt6->bindParam(3, $p_amount, PDO::PARAM_STR);
    $stmt6->bindParam(4, $pcust_id, PDO::PARAM_STR);
    $stmt6->bindParam(5, $p_method, PDO::PARAM_STR);
    $stmt6->execute();
}

$query7 = "SELECT * FROM orderdetails ORDER BY `date` DESC LIMIT 1";
$stmt7 = $con->prepare($query7);
$stmt7->execute();
$result2 = $stmt7->fetch(PDO::FETCH_OBJ);



$query8 = "SELECT * FROM `booktable` b join orderdetails o on b.tcust_id=o.ocust_id where o.ocust_id={$cid} order by o.date desc LIMIT 1";
$stmt8 = $con->prepare($query8);
$stmt8->execute();
$result3 = $stmt8->fetch(PDO::FETCH_OBJ);

if(isset($_POST['btn-feedback'])){
    
    $_restaurant_id = $_GET['id'];
    $cid = $record3->C_id;
    $f_feedback = $_POST['f_feedback'];
    $query9="INSERT INTO `feedback`(`fcust_id`, `frest_id`, `f_feedback`) VALUES (?,?,?)";
    $stmt9=$con->prepare($query9);
    
    $stmt9->bindParam(1,$cid);
    $stmt9->bindParam(2,$_restaurant_id);
    $stmt9->bindParam(3,$f_feedback);
    $stmt9->execute();

}




?>
<div class="py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Checkout Confirmation</h1>
        <!-- <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Service</li>
                        </ol>
                    </nav> -->
    </div>
</div>
</div>
<div class="container top_spacing" style="padding-bottom: 30px">

    <div style="max-width:600px; margin:0 auto;">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div style="float: left;"><i class="si si-check" style="font-size: 55px;"></i></div>
            <div style="float: left; padding-left: 10px;">
                <h2 class="text-center" style="margin-top: 5px;font-size: 20px;color:#D29055;">Thanks,
                    <?php echo $record3->c_name ?>! Your
                    reservation is confirmed.
                </h2>
                <span class="text-center" style="color:#fff;">Confirmation #810</span>
            </div>
        </div>


        <!--code for jazzcash starts here-->



        <!--code for jazzcash ends here-->

        <div class="col-xs-12 col-sm-12 col-md-6" style=" background:#f6f6f6;">
            <div class="col-md-12"
                style="background-color:  white;padding:  20px;margin:20px 0 20px 0px ;min-height:200px;">
                <div style="font-size: 20px;"><b>
                        <?php foreach ($record as $r) {
                            echo $r->r_name;
                        } ?>
                    </b>
                    <!-- <span> </span><i style="font-size: 12px" class="fa fa-pencil"></i><a href="#" style="text-decoration:  underline; font-size: 12px; color: blue"> Edit booking</a> -->
                </div>
                <div><i class="fa fa-calendar" style="color:#aaa; "></i><span
                        style="margin-right: 10px; margin-left: 5px"> Date of Booking: </span>
                    <?php echo $result2->date; ?>
                </div>
                <div><i class="fa fa-user" style="color:#aaa; "></i><span style="margin-right: 10px; margin-left: 5px">
                        Guests Quantity: </span>
                    <?php echo $result3->no_of_peoples; ?>
                </div>
                <div><i class="fa fa-birthday-cake" style="color:#aaa;"></i><span
                        style="margin-right: 10px; margin-left: 5px"> Special Notes: <?php echo $result3->request; ?>
                    </span> </div>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-6" style=" background:#f6f6f6;">

            <div class="col-md-12"
                style="background-color:  white;padding:  20px;margin:20px 0 20px 0px ;min-height:200px;">
                <div style="font-size: 20px; margin-bottom:20px;"><b> Contact Information </b> </div>
                <div><i class="fa fa-map-marker" style="color:#aaa;"></i><span
                        style="margin-right: 10px; margin-left: 5px"> Address: </span>
                    <?php echo $record3->c_address; ?>
                </div>
                <div><i class="fa fa-phone" style="color:#aaa;"></i><span style="margin-right: 10px; margin-left: 5px">
                        Phone: </span>
                    <?php echo $record3->c_contact; ?>
                </div>
            </div>
        </div>



    </div>
</div>
<div class="container">
    <div class="row">
        <form action="<?php echo $_SERVER['PHP_SELF']."?id=".$_restaurant_id?>" method="post" >
        <!-- <div class="mb-3">
                <h2>Rate your experience</h2>
            </div> -->
            <!-- <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" required>
            </div> -->
            <div class="mb-3">
                <label for="message" class="form-label">Feedback</label>
                <textarea class="form-control" id="message" rows="5" name="f_feedback" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary" name="btn-feedback">Submit</button>
        </form>

    </div>
</div>
<?php
include('./template/footer.php');
?>