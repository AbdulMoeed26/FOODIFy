<?php
session_start();
include('./template/header.php');
include('./config.php');
$db = new Dbconnection();
$con = $db->getConnection();

if ( !$_SESSION[ 'loggeduser' ] ) {
    header( 'Location: ./customer-register.php?fail="unauth"' );
}



$c_email = $_SESSION[ 'loggeduser' ];
$query='select * from customer where c_email = ?';
$stmt= $con->prepare($query);
$stmt->bindParam( 1, $c_email );
$stmt->execute();
$result = $stmt->fetch();

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $_SESSION['food'][] = $id;

    $valueCounts = array_count_values($_SESSION['food']);
    $duplicates = [];

    foreach ($valueCounts as $value => $count) {
        if ($count > 1) {
            $duplicates[] = $value;
        }
    }

    function filter(&$array, $delete)
    {
        $key = array_search($delete, $array);
        if ($key !== false) {
            unset($array[$key]);
        }
        $array = array_values($array); // Reset array indexes
    }

    foreach ($duplicates as $duplicate) {
        filter($_SESSION['food'], $duplicate);
        break; // Remove only one occurrence of the duplicate value
    }
}


if(isset($_POST['quantity'])) {

    $name=$_POST['name'];
    $amount=$_POST['amount'];
    $qty3=$_POST['qty3'];
    $cid=$_POST['cid']; 

    for ($i=0; $i <count($name) ; $i++) { 

        $query = "INSERT INTO `cart`(`name`, `amount`, `quantity`, `cid`) VALUES ('{$name[$i]}','{$amount[$i]}','{$qty3[$i]}','{$cid}')";
        $stmt= $con->prepare($query);
        $stmt->execute();

        
    }
}
if (isset($_POST['backtomenu'])) {
    $currentpage = $_SESSION['currentpage'];
    header("Location: $currentpage");
    exit(); // It is essential to call exit or die after using header for redirection.
}


?>

    <div class="py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Add to cart</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Add to cart</li>
                </ol>
            </nav>
        </div>
    </div>


    <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>?cid=<?php echo $_GET['cid'] ?>">

        <?php if (isset($_POST['quantity'])) {
            $quant = array(); // Initialize the $quant array
            $amount = array();
            if (isset($_POST['id']) && isset($_POST['qty3'])) {
                $ids = $_POST['id'];
                $quantities = $_POST['qty3'];

                // Iterate over the arrays
                foreach ($ids as $index => $id) {
                    if (isset($quantities[$index])) {
                        $quantity = $quantities[$index];
                        $quant[$id] = $quantity;
                        $amount[$id] = $_POST['amount'][$index]; // Get the corresponding amount from $_POST['amount']
                    }
                }
            }

            $values1 = array_values($quant);
            $values2 = array_values($amount);
            $paise=array();
            for ($i = 0; $i < count($values1); $i++) {
                $paise[$i] = $values1[$i]  * $values2[$i];
                // array_push($value, $paise);
                
            }
        
            $totalamount = array_sum($paise);
            // print_r($quant);
            // print_r($amount);
            $_SESSION['totalamount']=$totalamount;
            // echo $_SESSION['totalamount'];
            
        }
        ?>

        <!-- Display table and form -->
        <table>
    <tbody>
        <?php foreach ($_SESSION['food'] as $id) { ?>
            <?php
            $query = $con->prepare("SELECT * FROM fooditem WHERE f_id = ?");
            $query->execute([$id]);
            $record = $query->fetch(PDO::FETCH_OBJ);
            if ($record) {
            ?>
                <tr>
                    <td><img class="flex-shrink-0 img-fluid rounded" src="admin/uploads/<?php echo $record->f_image; ?>" alt="" style="width: 80px;"></td>
                    <td><input type="text" value="<?php echo $record->f_name ?>" readonly name="name[]" required></td>
                    <td><input type="hidden" value="<?php echo $record->f_id ?>" readonly name="id[]"></td>
                    <td><input type="number" value="<?php echo $record->f_price ?>" readonly name="amount[]" required></td>
                    <td><input type="number" name="qty3[]" value="1" min="1" max="5" class="horiz" pattern="[0-9]" style="outline: none;"></td>
                    <td><input type="hidden" name="cid" value="<?php echo $_GET['cid'] ?>"></td>
                
                </tr>
        <?php }
        } ?>
    </tbody>
    <input  type="submit" name="backtomenu" value="Bact To Menu">
</table>

<input type="submit" name="quantity" value="Total   ">
</form>

<h4>Total Amount: <?php if(isset($totalamount)){echo $totalamount;}?></h4>


<?php
include('./template/footer.php');
?>