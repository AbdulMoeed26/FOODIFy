<?php
include('./template/header.php');
include('./session.php');


$record = []; // Initialize $record as an empty array
$email = $_SESSION['loggeduser'];

if (isset($_GET['id'])) {
    $_restaurant_id = $_GET['id'];
    $query1 = "select * from resataurant_reg where r_id =" . $_restaurant_id;
    $stmt1 = $con->prepare($query1);
    $stmt1->execute();
    $record = $stmt1->fetchAll(PDO::FETCH_OBJ);
}

// Retrieve the record for the logged-in user
$query3 = "SELECT * FROM customer WHERE c_email = :email";
$stmt3 = $con->prepare($query3);
$stmt3->bindParam(':email', $email, PDO::PARAM_STR);
$stmt3->execute();
$record3 = $stmt3->fetch(PDO::FETCH_OBJ);

// Retrieve the number of people and date for the logged-in user
$query4 = "SELECT booktable.no_of_peoples, booktable.date
FROM customer
JOIN booktable ON customer.c_id = booktable.tcust_id
WHERE customer.c_email = :email
LIMIT 1";
$stmt4 = $con->prepare($query4);
$stmt4->bindParam(':email', $email, PDO::PARAM_STR);
$stmt4->execute();
$result = $stmt4->fetch(PDO::FETCH_OBJ);

$query5 = "SELECT * FROM orderdetails ORDER BY `date` DESC LIMIT 1";
$stmt5 = $con->prepare($query5);
$stmt5->execute();
$result2 = $stmt5->fetch(PDO::FETCH_OBJ);



?>

<div class="py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Checkout</h1>
    </div>
</div>
<div class="container">
    <div class="row">
        <h2>Your Checkout</h2>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Number of People</th>
                    <th scope="col">Date</th>
                    <th scope="col">Restaurant</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">
                        <?php echo $result->no_of_peoples; ?>
                    </th>
                    <td>
                        <?php echo $result->date; ?>
                    </td>
                    <td>
                        <?php foreach ($record as $row)
                            echo $row->r_name; ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <p>We are holding this table for you for 5:00 minutes</p>

        <form method="post" action="confirmcheckout.php?id=<?php echo $row->r_id; ?>">
            <div class="row g-3">
                <div class="col-md-12">
                    <div class="form-floating">
                        <select type="text" class="form-control" id="address" placeholder="First Name" name="c_name">
                            <option>
                                <?php echo $record3->c_name; ?>
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select type="text" class="form-control" id="address" placeholder="First Name" name="c_contact">
                            <option>
                                <?php echo $record3->c_contact; ?>
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-floating">
                        <select type="text" class="form-control" id="address" name="c_email">
                            <option>
                                <?php echo $record3->c_email; ?>
                            </option>
                        </select>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-floating">
                        <select type="text" class="form-control" id="address" name="c_address">
                            <option>
                                <?php echo $record3->c_address; ?>
                            </option>
                        </select>
                    </div>
                </div>
                <input class="form-control" type="hidden" name="porder_id" value="<?php echo $result2->o_id ?>">
                <input class="form-control" type="text" name="p_amount" value="<?php echo $_SESSION['totalamount'] ?>"
                    readonly>
                <input class="form-control" type="hidden" name="pcust_id" value="<?php echo $record3->C_id ?>" readonly>
                <input class="form-control" type="hidden" name="prest_id" value="<?php echo $_GET['id']; ?>" readonly>


                <div class="col-12">
                    <div class="form-floating">
                        <select name="p_method" class="form-select" style="padding: 0px 10px;">
                            <option value="method">Select Payment Method</option>
                            <option value="By_Hand">By Hand</option>
                            <option value="Voucher">Jazz Cash Voucher</option>
                            <option value="Mobile_Account">Jazzcash Mobile Account</option>
                            <option value="Credit_card">Credit/Debit Card</option>
                        </select>
                    </div>
                </div>
                <div class="col-12">
                    <input class="form-control btn btn-primary py-2 px-4" type="submit" name="confirm">
                </div>
            </div>
        </form>
    </div>
</div>

<?php
include('./template/footer.php');
?>