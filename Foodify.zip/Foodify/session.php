<?php
session_start();

if ( !$_SESSION[ 'loggeduser' ] ) {
    header( 'Location: ./customer-register.php?fail="unauth"' );
}
$c_email = $_SESSION[ 'loggeduser' ];

include( './config.php' );
$db = new Dbconnection();
$con = $db->getConnection();

$query='select * from customer where c_email = ?';
$stmt= $con->prepare($query);
$stmt->bindParam( 1, $c_email );
$stmt->execute();
$result = $stmt->fetch();


if ( isset( $_POST[ 'logout' ] ) ) {
    session_unset();
    session_destroy();
    header( 'Location: ./customer-register.php' );
}

?>