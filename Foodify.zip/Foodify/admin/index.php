<?php
include('./template/header.php');

$rest_id=$result['r_id'];

$query="SELECT SUM(p_amount) FROM `payment` where prest_id = {$rest_id}";
$stmt=$con->prepare($query);
$stmt->execute();
$record=$stmt->fetch(PDO::FETCH_ASSOC);

$query1="select COUNT(porder_id) from payment WHERE prest_id= {$rest_id}";
$stmt1=$con->prepare($query1);
$stmt1->execute();
$record1=$stmt1->fetch(PDO::FETCH_ASSOC);

$query2="select COUNT(pcust_id) from payment WHERE prest_id= {$rest_id}";
$stmt2=$con->prepare($query2);
$stmt2->execute();
$record2=$stmt2->fetch(PDO::FETCH_ASSOC);



?>

        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Dashboard <span>/ Menu-Details  </span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <!-- Top Report Wrap Start -->
            <div class="row">
                <!-- Top Report Start -->
                <div class="col-xlg-3 col-md-6 col-12 mb-30">
                    <div class="top-report">

                        <!-- Head -->
                        <div class="head">
                            <h4>Total Visitor</h4>
                            <a href="#" class="view"><i class="zmdi zmdi-eye"></i></a>
                        </div>

                        <!-- Content -->
                        <div class="content">
                            <h5>Todays</h5>
                            <h2><?php foreach($record2 as $row2){
                                
                                if(empty($row2)){echo "0";}
                                else{echo $row2;} 
                                };?></h2>
                        </div>


                    </div>
                </div><!-- Top Report End -->


                <!-- Top Report Start -->
                <div class="col-xlg-3 col-md-6 col-12 mb-30">
                    <div class="top-report">

                        <!-- Head -->
                        <div class="head">
                            <h4>Order Received</h4>
                            <a href="#" class="view"><i class="zmdi zmdi-eye"></i></a>
                        </div>

                        <!-- Content -->
                        <div class="content">
                            <h5>Todays</h5>
                            <h2><?php foreach($record1 as $row1){
                                
                                if(empty($row1)){echo "0";}
                                else{echo $row1;} 
                                };?></h2>
                        </div>


                    </div>
                </div><!-- Top Report End -->

                <!-- Top Report Start -->
                <div class="col-xlg-3 col-md-6 col-12 mb-30">
                    <div class="top-report">

                        <!-- Head -->
                        <div class="head">
                            <h4>Total Revenue</h4>
                            <a href="#" class="view"><i class="zmdi zmdi-eye"></i></a>
                        </div>

                        <!-- Content -->
                        <div class="content">
                            <h5>Todays</h5>
                            <h2><?php foreach($record as $row){
                                
                                if(empty($row)){echo "0.00";}
                                else{echo $row;} 
                                };?></h2>
                        </div>

                    </div>
                </div><!-- Top Report End -->
            </div><!-- Top Report Wrap End -->
        </div>

<?php
include('./template/footer.php');
?>