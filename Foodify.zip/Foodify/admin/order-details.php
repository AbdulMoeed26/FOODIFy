<?php 
include ('./template/header.php');

$record = [];
$r_email = $_SESSION['loggeduser'];

$query = "SELECT * FROM resataurant_reg WHERE r_email = '{$r_email}'";
$stmt = $con->prepare($query);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$rid = $results[0]['r_id'];

$query1 = "SELECT o.o_id, c.c_name, r.r_name, b.t_name,o.date
FROM customer c
JOIN orderdetails o ON c.C_id = o.ocust_id
JOIN resataurant_reg r ON o.orest_id = r.r_id
JOIN booktable b ON o.otbl_id = b.t_id
WHERE r.r_id = {$rid}";

$stmt1 = $con->prepare($query1);
$stmt1->execute();
$records1 = $stmt1->fetchAll(PDO::FETCH_ASSOC);



?>
        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Menu-Details <span>/ Order Details</span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <div class="row mbn-30">

                <!--Order Details Head Start-->
                <div class="col-12 mb-30">
                    <div class="row mbn-15">
                        <div class="col-12 col-md-4 mb-15">
                            <h4 class="text-primary fw-600 m-0">Order ID# MSP40022</h4>
                        </div>
                        <div class="text-left text-md-center col-12 col-md-4 mb-15"><span>Status: <span class="badge badge-round badge-success">Shipping</span></span></div>
                        <div class="text-left text-md-right col-12 col-md-4 mb-15">
                            <p>02 February, 2018</p>
                        </div>
                    </div>
                </div>
                <!--Order Details Head End-->


                <!--Order Details List Start-->
                <div class="col-12 mb-30">
                    <div class="table-responsive">
                        <table class="table table-bordered table-vertical-middle">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer Name</th>
                                    <th>Restaurant Name</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <?php foreach ($records1 as $row) { ?>
    <tbody>
        <tr>
            <td><?php echo $row['o_id']; ?></td>
            <td><?php echo $row['c_name']; ?></td>
            <td><?php echo $row['r_name']; ?></td>
            <td><?php echo $row['date']; ?></td>
        </tr>
    </tbody>
<?php } ?>

                        </table>
                        
                    </div>
                </div>
                <!--Order Details List End-->

            </div>

        </div><!-- Content Body End -->
  
  
<?php 
include ('./template/footer.php');
?>