<?php 
include ('./template/header.php');
$query = $con->prepare("select * from fooditem");
$query->execute();
$record = $query->fetchAll(PDO::FETCH_OBJ);
?>

        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Menu-Details <span>/ Manage Product</span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product ID</th>
                                    <th>Photo</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Status</th>                                   
                                    <th>Description</th>
                                    <th>Food Category</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                        <?php
                        foreach ($record as $row) { ?>
                                <tr>
                                    <td><?php echo $row->f_id?></td>
                                    <td>
                                    <img src='<?php echo "./uploads/$row->f_image" ?>' alt="" width="80px" height="80px" >
                                </td>                                   
                                 <td><?php echo $row->f_name?></td>
                                    <td><?php echo $row->f_price?></td>
                                    <td><?php echo $row->f_status?></td>
                                    <td><?php echo $row->f_desc?></td>
                                    <td><?php echo $row->f_catid?></td>
                
                                    <td>
                                        <div class="table-action-buttons">
                                            <a class="edit button button-box button-xs button-info" href="./edit-product.php?id=<?php echo $row->f_id ?>"><i class="zmdi zmdi-edit"></i></a>
                                            <a class="delete button button-box button-xs button-danger" href="./delete-product.php?id=<?php echo $row->f_id ?>"><i class="zmdi zmdi-delete"></i></a>
                                        </div>
                                    </td>
                        </tr>
                                
                                <?php }
                        ?>
                            </tbody>
                        </table>
                    </div>
        </div><!-- Content Body End -->

<?php 
include ('./template/footer.php');
?>