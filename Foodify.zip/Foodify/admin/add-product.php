<?php
include('./template/header.php');

$record = [];

if (isset($_GET['id'])) {
    $_food_id = $_GET['id'];

    $query6 = "SELECT * FROM fooditem WHERE f_id = :food_id";
    $stmt6 = $con->prepare($query6);
    $stmt6->bindParam(':food_id', $_food_id, PDO::PARAM_INT);
    $stmt6->execute();
    $record = $stmt6->fetchAll(PDO::FETCH_OBJ);
}

if (isset($_POST['btn-menu'])) {
    $filename = $_FILES['f_image']['name'];
    $file_tmpname = $_FILES['f_image']['tmp_name'];
    move_uploaded_file($file_tmpname, "./uploads/$filename");

    $f_name = $_POST['f_name'];
    $f_status = $_POST['f_status'];
    $f_price = $_POST['f_price'];
    $f_image = $filename;
    $f_desc = $_POST['f_desc'];
    $f_catid = $_POST['f_catid'];

    $query1 = $con->prepare("INSERT INTO fooditem (f_name, f_status, f_price, f_image, f_desc, f_catid) VALUES (?, ?, ?, ?, ?, ?)");
    $query1->bindParam(1, $f_name);
    $query1->bindParam(2, $f_status);
    $query1->bindParam(3, $f_price);
    $query1->bindParam(4, $f_image);
    $query1->bindParam(5, $f_desc);
    $query1->bindParam(6, $f_catid);
    $query1->execute();
}
?>



        <!-- Content Body Start -->
        <div class="content-body">

            <!-- Page Headings Start -->
            <div class="row justify-content-between align-items-center mb-10">

                <!-- Page Heading Start -->
                <div class="col-12 col-lg-auto mb-20">
                    <div class="page-heading">
                        <h3>Menu-Details <span>/ Add Product</span></h3>
                    </div>
                </div><!-- Page Heading End -->

            </div><!-- Page Headings End -->

            <!-- Add or Edit Product Start -->
            <div class="add-edit-product-wrap col-12">

                <div class="add-edit-product-form">
                    <form action="" method="post" enctype="multipart/form-data">

                        <h4 class="title">About Product</h4>

                        <div class="row">
                            <div class="col-lg-6 col-12 mb-30"><input class="form-control" type="text" placeholder="Product Name / Title*" name="f_name"></div>
                            <div class="col-lg-6 col-12 mb-30"><input class="form-control" type="text" placeholder="Product Status" name="f_status"></div>
                            <div class="col-12 mb-30"><input class="form-control" placeholder="Product Description*" name="f_desc"></div>
                            <div class="col-lg-6 col-12 mb-30">
                                <input class="form-control" type="text" placeholder="price" name="f_price">
                            </div>

                            <div class="col-lg-6 col-12 mb-30">
                                <label>Category</label>
                                <select name="f_catid" id="">
                                    <option>fastfood</option>
                                    <option>Desi</option>
                                </select>

                        </div>

                        <h4 class="title">Product Gallery</h4>

                        <div class="product-upload-gallery row flex-wrap">
                            <div class="col-12 mb-30">
                                <p class="form-help-text mt-0">Upload Maximum 800 x 800 px & Max size 2mb.</p>
                                <input  type="file" name="f_image">
                            </div>
                        </div>

                                
                        <!-- Button Group Start -->
                        <div class="row">
                            <div class="d-flex flex-wrap justify-content-end col mbn-10">
                            <button class="button button-outline button-primary mb-10 ml-10 mr-0" name="btn-menu">Save & Publish</button>
                           
    <button class="button button-outline button-info mb-10 ml-10 mr-0">Save to Draft</button>

                                <button class="button button-outline button-danger mb-10 ml-10 mr-0">Delete Product</button>
                            </div>
                        </div><!-- Button Group End -->

                    </form>
                </div>

            </div><!-- Add or Edit Product End -->

        </div><!-- Content Body End -->

<?php include('./template/footer.php'); ?>