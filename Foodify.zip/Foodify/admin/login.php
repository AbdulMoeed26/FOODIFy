<?php

session_start();
if ( isset( $_SESSION[ 'loggedUser' ] ) ) {
    header( 'Location: ./index.php' );
}

if ( isset( $_GET[ 'fail' ] ) ) {
}

include( '../config.php' );
$db = new DBConnection;
$con = $db->getConnection();

if ( isset( $_POST[ 'btn-signup' ] ) ) {

    $filename = $_FILES[ 'r_image' ][ 'name' ];
    $file_tmpname = $_FILES[ 'r_image' ][ 'tmp_name' ];
    move_uploaded_file( $file_tmpname, './upload' );

    $r_name = $_POST[ 'r_name' ];
    $r_email = $_POST[ 'r_email' ];
    $r_city = $_POST[ 'r_city' ];
    $r_password = $_POST[ 'r_password' ];
    $r_confirmpassword = $_POST[ 'r_confirmpassword' ];
    $r_address = $_POST[ 'r_address' ];
    $r_image = $filename;

    $str_result = strcmp( $r_password,  $r_confirmpassword );
    if ( $str_result != 0 ) {

        $message = "password doesn't match";

    } else {
        $query1 = $con->prepare( 'insert into resataurant_reg(r_name,r_email,r_city,r_password,r_confirmpassword,r_address,r_image)values(?,?,?,?,?,?,?)' );
        $query1->bindParam( 1, $r_name );
        $query1->bindParam( 2, $r_email );
        $query1->bindParam( 3, $r_city );
        $query1->bindParam( 4, $r_password );
        $query1->bindParam( 5, $r_confirmpassword );
        $query1->bindParam( 6, $r_address );
        $query1->bindParam( 7, $r_image );
        $query1->execute();

    }
}

if ( isset( $_POST[ 'btn-login' ] ) ) {
    $r_email = $_POST[ 'r_email' ];
    $r_password = $_POST[ 'r_password' ];

    $query2 = $con->prepare( 'select * from resataurant_reg where r_email=? && r_password=?' );
    $query2->bindParam( 1, $r_email );
    $query2->bindParam( 2, $r_password );
    $query2->execute();
    $count = $query2->rowCount();

    if ( $count > 0 ) {
        $_SESSION[ 'loggeduser' ] = $r_email;
        header( 'Location: ./index.php' );
    } else
    $msg = 'invalid email or username';

}

?>

<!doctype html>
<html class = 'no-js' lang = 'en'>

<head>
<meta charset = 'utf-8'>
<meta http-equiv = 'x-ua-compatible' content = 'ie=edge'>
<title>Foodify </title>
<meta name = 'robots' content = 'noindex, follow' />
<meta name = 'description' content = ''>
<meta name = 'viewport' content = 'width=device-width, initial-scale=1, shrink-to-fit=no'>
<!-- Favicon -->
<link rel = 'shortcut icon' type = 'image/x-icon' href = 'assets/images/favicon.ico'>

<!-- CSS
===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == -->

<!-- Bootstrap CSS -->
<link rel = 'stylesheet' href = 'assets/css/vendor/bootstrap.min.css'>

<!-- Icon Font CSS -->
<link rel = 'stylesheet' href = 'assets/css/vendor/material-design-iconic-font.min.css'>
<link rel = 'stylesheet' href = 'assets/css/vendor/font-awesome.min.css'>
<link rel = 'stylesheet' href = 'assets/css/vendor/themify-icons.css'>
<link rel = 'stylesheet' href = 'assets/css/vendor/cryptocurrency-icons.css'>

<!-- Plugins CSS -->
<link rel = 'stylesheet' href = 'assets/css/plugins/plugins.css'>

<!-- Helper CSS -->
<link rel = 'stylesheet' href = 'assets/css/helper.css'>

<!-- Main Style CSS -->
<link rel = 'stylesheet' href = 'assets/css/style.css'>

<!-- Custom Style CSS Only For Demo Purpose -->
<link id = 'cus-style' rel = 'stylesheet' href = 'assets/css/style-primary.css'>

</head>

<body>

<div class = 'main-wrapper'>

<!-- Content Body Start -->
<div class = 'content-body m-0 p-0'>
<div class = 'container'>
<div class = 'row'>
<div class = 'col-md-6'>
<form action = '' method = 'post'>
<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example3'>Email address</label>
<input type = 'email' id = 'form3Example3' class = 'form-control' name = 'r_email' />

</div>

<!-- Password input -->
<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example4'>Password</label>
<input type = 'password' id = 'form3Example4' class = 'form-control' name = 'r_password' />
</div>

<!-- Submit button -->
<button type = 'submit' class = 'btn btn-primary btn-block mb-4' name = 'btn-login'>
Log in
</button>
</form>
</div>
<div class = 'col-md-6'>
<div class = 'card-body py-5 px-md-5'>
<form method = 'post' enctype = 'multipart/form-data'>
<!-- 2 column grid layout with text inputs for the first and last names -->
<div class = 'row'>
<div class = 'form-outline mb-4'>
<div class = 'form-outline'>
<label class = 'form-label' for = 'form3Example3'>Name</label>

<input type = 'text' id = 'form3Example3' class = 'form-control' name = 'r_name' required/>
</div>
</div>
</div>

<!-- Email input -->
<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example3'>Email address</label>

<input type = 'email' id = 'form3Example3' class = 'form-control' name = 'r_email' required/>
</div>

<!-- city input -->
<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example3'>City</label>

<input type = 'text' id = 'form3Example3' class = 'form-control' name = 'r_city' required/>
</div>

<!-- Password input -->
<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example4'>Password</label>

<input type = 'password' id = 'form3Example4' class = 'form-control' name = 'r_password' required/>
</div>

<div class = 'form-outline mb-4'>
<label class = 'form-label' for = 'form3Example4'>Confirm Password</label>
<input type = 'password' id = 'form3Example4' class = 'form-control' name = 'r_confirmpassword' required/>

</div>

<div class = 'row'>
<div class = 'form-outline mb-4'>
<div class = 'form-outline'>
<label class = 'form-label' for = 'form3Example1'>Address</label>

<input type = 'text' id = 'form3Example1' class = 'form-control' name = 'r_address' required/>
</div>
</div>
</div>

<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'file' placeholder = ''
name = 'r_image'required>
</div>

<?php
if ( isset( $message ) ) {
    ?>
    <div class = 'alert alert-danger'>
    <?php echo $message;
    ?>
    </div>
    <?php
}

?>

<!-- Submit button -->
<button type = 'submit' class = 'btn btn-primary btn-block mb-4' name = 'btn-signup'>
Sign up
</button>

<!-- Register buttons -->
<div class = 'text-center'>
<p>or sign up with:</p>
<button type = 'button' class = 'btn btn-link btn-floating mx-1'>
<i class = 'fab fa-facebook-f'></i>
</button>

<button type = 'button' class = 'btn btn-link btn-floating mx-1'>
<i class = 'fab fa-google'></i>
</button>

<button type = 'button' class = 'btn btn-link btn-floating mx-1'>
<i class = 'fab fa-twitter'></i>
</button>

<button type = 'button' class = 'btn btn-link btn-floating mx-1'>
<i class = 'fab fa-github'></i>
</button>
</div>
</form>

</div>
</div>
</div>
</div>

</div><!-- Content Body End -->

</div>

<!-- JS
===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  ===  == -->

<!-- Global Vendor, plugins & Activation JS -->
<script src = 'assets/js/vendor/modernizr-3.6.0.min.js'></script>
<script src = 'assets/js/vendor/jquery-3.3.1.min.js'></script>
<script src = 'assets/js/vendor/popper.min.js'></script>
<script src = 'assets/js/vendor/bootstrap.min.js'></script>
<!--Plugins JS-->
<script src = 'assets/js/plugins/perfect-scrollbar.min.js'></script>
<script src = 'assets/js/plugins/tippy4.min.js.js'></script>
<!--Main JS-->
<script src = 'assets/js/main.js'></script>

</body>

</html>