<?php
include ('./template/header.php');

$r_email = $_SESSION['loggeduser'];

$query = "SELECT p.*, c.c_name, r.r_name 
          FROM payment p
          INNER JOIN customer c ON p.pcust_id = c.c_id
          INNER JOIN resataurant_reg r ON p.prest_id = r.r_id
          WHERE r.r_email = '{$r_email}'";
$stmt = $con->prepare($query);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
?>

<!-- Content Body Start -->
<div class="content-body">
    <!-- Page Headings Start -->
    <div class="row justify-content-between align-items-center mb-10">
        <!-- Page Heading Start -->
        <div class="col-12 col-lg-auto mb-20">
            <div class="page-heading">
                <h3>Invoice Details</h3>
            </div>
        </div><!-- Page Heading End -->
    </div><!-- Page Headings End -->
    <div class="row mbn-30">
        <!--Invoice Details Table Start-->
        <div class="col-12 mb-30">
            <div class="table-responsive">
                <table class="table table-bordered mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th><span>Customer</span></th>
                            <th class="text-right"><span>Order Id</span></th>
                            <th class="text-right"><span>Restaurant</span></th>
                            <th class="text-right"><span>Total Amount</span></th>
                            <th class="text-right"><span>Payment Method</span></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($results as $r1){?>
                        <tr>
                            <td><?php echo $r1->p_id;?></td>
                            <td><?php echo $r1->c_name;?></td> <!-- Display customer name -->
                            <td class="text-right"><?php echo $r1->porder_id;?></td>
                            <td class="text-right"><?php echo $r1->r_name;?></td> <!-- Display restaurant name -->
                            <td class="text-right"><?php echo $r1->p_amount;?></td>
                            <td class="text-right"><?php echo $r1->p_method;?></td>
                        </tr>
                        <?php }?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--Invoice Details Table End-->

        <div class="col-12 mb-15">
            <hr>
        </div>

        <!--Invoice Action Button Start-->
        <div class="col-12 d-flex justify-content-end mb-30">
            <div class="buttons-group">
                <button class="button button-outline button-primary">Download PDF</button>
                <button class="button button-outline button-info">Send Print</button>
                <button class="button button-outline button-secondary">Payment Process</button>
            </div>
        </div>
        <!--Invoice Action Button Start-->

    </div>
</div><!-- Content Body End -->

<?php 
include ('./template/footer.php');
?>
