<?php

include('../config.php');

$db = new DBConnection();
$con = $db->getConnection();
$id = $_GET['id'];

$customer = $con->prepare("delete from fooditem where f_id = ?");
$customer->bindParam(1, $id);
$customer->execute();
header("Location: ./manage-products.php");

?>