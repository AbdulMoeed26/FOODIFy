<?php
session_start();

if (!isset($_SESSION['loggeduser'])) {
    header('Location: ./login.php?fail=unauth');
    exit();
}

$r_email = $_SESSION['loggeduser'];

include('../config.php');
$db = new DBConnection;
$con = $db->getConnection();

$query = 'SELECT * FROM resataurant_reg WHERE r_email = ?';
$stmt = $con->prepare($query);
$stmt->bindParam(1, $r_email);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ./login.php');
    exit();
}
?>
