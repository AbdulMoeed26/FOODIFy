<?php

include('template/header.php');

include('./session.php');
$email = $_SESSION['loggeduser'];

$record = []; // Initialize $record as an empty array

if (isset($_GET['id'])) {
    $_restaurant_id = $_GET['id'];

    $query1 = "select * from resataurant_reg where r_id = {$_restaurant_id}";
    $stmt1 = $con->prepare($query1);
    $stmt1->execute();
    $record = $stmt1->fetchAll(PDO::FETCH_OBJ);
}


$query2 = "select * from customer where c_email = '{$email}'";
$stmt2 = $con->prepare($query2);
$stmt2->execute();
$record1 = $stmt2->fetchAll(PDO::FETCH_OBJ);






foreach ($record as $row) { ?>
    <div class="py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">
                <?php echo $row->r_name; ?>
            </h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">Service</li>
                </ol>
            </nav>
        </div>
    </div>
    <?Php
} ?>
<div class="container  mt-10">
    <div class="row">
        <div class="col-md-8">
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home"
                        type="button" role="tab" aria-controls="nav-home" aria-selected="true">Restaurant Info</button>
                </div>
            </nav>


            <div>
                <h2> Seating Styles</h2>
                <p>Separate Dinning For Families, indoor</p>
                <h2>Cuisine</h2>
                <p>Continental, Pakistani, BBQ, Fast Food, Lahori Style</p>
                <h2> Hours of operation</h2>
                <p>Sunday12:00 AM to 05:00 AM 11:00 AM to 11:59 PM </p>
                <h2> Contact Information</h2>
                <p>Address: Expo Center Road Block H-3 Johar Town Lahore </p>
                <p> Phone number: 03224253097</p>

            </div>

        </div>

        <div class="form-container col-md-4">
            <form action="menu.php?id=<?php echo $row->r_id; ?>" method="post">
                <div class="">
                    <h2>Make a reservation</h2>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" id="address" placeholder="Your Address">
                                <label for="name">Your Address</label>
                            </div>
                        </div>

                        <?php foreach ($record as $row) { ?>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <div class="form-floating">
                                        <select class="form-select" disabled id="select1" name="trest_id">
                                            <option value="<?php echo $row->r_id; ?>"><?php echo $row->r_name; ?></option>
                                        </select>
                                        <label for="select1">Restaurants </label>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <div class="col-md-12">
                            <div class="form-floating date" id="date3" data-target-input="nearest">
                                <input type="text" class="form-control datetimepicker-input" id="datetime"
                                    placeholder="Date & Time" data-target="#date3" data-toggle="datetimepicker"
                                    name="date" />
                                <label for="datetime">Date & Time</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-floating">

                                <input type="text" class="form-control" name="no_of_peoples">
                                <label for="select1">No Of People</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="request">
                                <label for="message">Special Request</label>
                            </div>
                        </div>

                        <?php foreach ($record1 as $row1) { ?>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <select type="text" class="form-control" name="tcust_id">
                                        <label for="message">Customer id </label>
                                        <option value="<?php echo $row1->C_id; ?>"><?php echo $row1->c_name; ?></option>
                                    </select>
                                </div>
                            <?php } ?>
                        </div>
                        <!-- <div class="col-md-12">
                            <div class="form-floating">
                                <input type="text" class="form-control" name="trest_id">
                                <label for="message">Rest id </label>
                            </div>
                        </div> -->

                        <div class="col-md-12">
                            <div class="form-floating">
                                <select type="text" class="form-control" name="t_name">
                                    <?php for ($i = 0; $i < $row->r_tables; $i++) {
                                        ?>
                                        <option value="<?php echo "no" . $i; ?>"><?php echo "no" . $i; ?></option>
                                    <?php } ?>
                                </select>
                                <label for="t_name">Table Name</label>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <!-- <a href="Checkout.php" class="btn btn-primary w-100 py-3" type="submit">Book Your Table</a> -->
                            <!-- <a href="RestaurantBook.php?id=<?php echo $row->r_id; ?>" class="btn btn-primary btn-block mb-4" name="btn-book">book Table </a> -->
                            <!-- <input type="submit" name="btn-book"> -->
                            <button class="btn btn-primary py-1 px-3">submit</button>
                        </div>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

<?php
include('./template/footer.php');
?>