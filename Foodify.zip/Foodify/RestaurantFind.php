<?php

include('./template/header.php');

include('./session.php');

$query1 = "select * from resataurant_reg";
$stmt1 = $con->prepare($query1);
$stmt1->execute();
$record = $stmt1->fetchAll(PDO::FETCH_OBJ);
?>

<div class="py-5 bg-dark hero-header mb-5">
    <div class="container text-center my-5 pt-5 pb-4">
        <h1 class="display-3 text-white mb-3 animated slideInDown">Book A Restaurant</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb justify-content-center text-uppercase">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item text-white active" aria-current="page">Book Restaurants</li>
            </ol>
        </nav>
    </div>
</div>
</div>
<div class="container">

    <div class="row">
        <?php

        foreach ($record as $row) { ?>

            <div class="card col-lg-4 mr-5">
                <div style="
    height: 300px;
    display: flex;
    align-items: center;
">
                    <img class="card-img-top" style="width:100%;    max-height: 300px;"
                        src="upload/<?php echo $row->r_image; ?>" alt="">
                </div>
                <div class="card-body">
                    <h5 class="card-title">
                        <?php echo $row->r_name; ?>
                    </h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional
                        content. This content is a little bit longer.</p>

                    <div class="col-12">
                        <a href="RestaurantBook.php ?id=<?php echo $row->r_id; ?>" class="btn btn-primary btn-block mb-4"
                            name="btn-find">Find Table </a>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>
</div>


<?php
include('./template/footer.php');
?>